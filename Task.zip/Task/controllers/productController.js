const Product = require('../models/Product');
const Category = require('../models/Category');

const getAllProducts = async (req, res) => {
    try {
        const products = await Product.find().populate({ path: 'category', strictPopulate: false }).populate('user');
        res.render('products/productList', { products });
    } catch (error) {
        res.status(500).send('Error fetching products');
    }
};

const getUserProducts = async (req, res) => {
    const products = await Product.find({ user: req.user.id });
    res.render('products/myProducts', { products });
};

// Fetch categories and render the form
const renderCreateProductForm = async (req, res) => {
    try {
        const categories = await Category.find();
        res.render('products/productForm', { categories });
    } catch (error) {
        res.status(500).send('Error fetching categories');
    }
};

const createProduct = async (req, res) => {
    try {
        const { name, description, price } = req.body;
        const image = req.file ? req.file.path : '';  // Store the image path

        const product = new Product({
            name,
            description,
            price,
            image,
            user: req.user.id
        });
        await product.save();
        res.redirect('/products');
    } catch (error) {
        res.status(500).send('Error creating product');
    }
};


module.exports = { getAllProducts, getUserProducts, createProduct, renderCreateProductForm };
