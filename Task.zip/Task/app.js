const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');

const authRoutes = require('./routes/authRoutes');
const productRoutes = require('./routes/productRoutes');
const ConnectDB = require('./Config/DB');

const app = express();

ConnectDB()
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Routes
app.use(authRoutes);
app.use(productRoutes);

const PORT = 3600;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
