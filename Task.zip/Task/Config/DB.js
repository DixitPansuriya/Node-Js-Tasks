const mongoose = require('mongoose');

const ConnectDB = async () => {
    try {
        await mongoose.connect('mongodb+srv://renilbhai1983:code123@cluster0.pu4so.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0');
        console.log('DB Connected Successfully...');
    } catch (error) {
        console.log('DB Connection Failed...');
        console.log(error);
    }
};

module.exports = ConnectDB;
