const express = require('express');
const multer = require('multer');
const { getAllProducts, getUserProducts, createProduct, renderCreateProductForm } = require('../controllers/productController');
const { requireAuth, checkRole } = require('../middleware/auth');

const router = express.Router();

// Set up Multer storage and file filter
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        } else {
            cb(new Error('Not an image! Please upload an image file.'), false);
        }
    }
});

// Routes
router.get('/products', requireAuth, getAllProducts);
router.get('/my-products', requireAuth, getUserProducts);
router.get('/products/new', requireAuth, renderCreateProductForm);
router.post('/products', requireAuth, checkRole(['admin', 'user']), upload.single('image'), createProduct);

module.exports = router;
