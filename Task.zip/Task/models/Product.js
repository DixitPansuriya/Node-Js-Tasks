const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: String,
    price: Number,
    image: String,  // Assuming you already added the image field
    category: { type: mongoose.Schema.Types.ObjectId, ref: 'Category' },  // This line is critical
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

const Product = mongoose.model('Product', ProductSchema);
module.exports = Product;
