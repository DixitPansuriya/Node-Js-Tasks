const express = require('express');
const router = express.Router();
const movieController = require('../controllers/movieController');

// Route to view all movies
router.get('/movies', movieController.getMovies);

// Route to show the form for adding a new movie
router.get('/movies/add', movieController.addMovie);

// Route to handle the form submission for creating a new movie
router.post('/movies', movieController.createMovie);

// Route to show the form for editing a specific movie
router.get('/movies/edit/:id', movieController.editMovie);

// Route to handle the form submission for updating a specific movie
router.post('/movies/edit/:id', movieController.updateMovie);

// Route to handle the deletion of a specific movie
router.post('/movies/delete/:id', movieController.deleteMovie);

module.exports = router;
    