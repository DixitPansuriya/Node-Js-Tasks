const express=require("express")
const path=require("path")
const app=express()



app.set("view engine","ejs")
app.use("/",express.static(path.join(__dirname+"/Public")))

const middleware=(req,res,next)=>{
    if(req.query.age >=18){
        return next()
    }

    return res.redirect("/")
}

app.get("/",(req,res)=>{
    res.render("index")
})

app.get("/home",middleware,(req,res)=>{
    res.render("home")
})



app.get("/contact",middleware,(req,res)=>{
    res.render("contact")
})
app.use(middleware)

app.listen(8790,()=>{
    console.log("Server in runnig on port on 8790")
})