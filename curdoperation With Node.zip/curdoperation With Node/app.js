const express = require("express");
const app = express();

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const validUsername = "dixit"; // Replace with your actual username
const validPassword = "dixit123"; // Replace with your actual password

let Mobiledata = [
    {
        id: 1,
        name: "Iphone 15",
        price: "74,000",
        img: "https://www.poojaratele.com/media/catalog/product/cache/4660d2675ce46398cb4d17672c98889f/i/1/i1_3.jpg"
    },
    {
        id: 2,
        name: "Samsung A15",
        price: "19,000",
        img: "https://www.poojaratele.com/media/catalog/product/cache/2ee311823438cb633f5cdd390f643aa6/a/1/a1_1_1.jpg"
    },
];

app.post("/validate", (req, res) => {
    const { username, password } = req.body;
    if (username === validUsername && password === validPassword) {
        res.json({ valid: true });
    } else {
        res.json({ valid: false });
    }
});

app.get("/", (req, res) => {
    res.render("index", { Mobile: Mobiledata });
});

app.post("/insert", (req, res) => {
    let userid = parseInt(req.body.id);
    let username = req.body.name;
    let userprice = req.body.price;
    let userimage = req.body.img;

    let obj = {
        id: userid,
        name: username,
        price: userprice,
        img: userimage
    };

    Mobiledata.push(obj);
    return res.redirect("/");
});

app.post("/delete/:id", (req, res) => {
    const idToDelete = parseInt(req.params.id);

    Mobiledata = Mobiledata.filter(Mobile => Mobile.id !== idToDelete);

    return res.redirect("/");
});

app.post("/edit/:id", (req, res) => {
    const idToEdit = parseInt(req.params.id);
    const updatedName = req.body.name;
    const updatedprice = req.body.price;
    const updatedimage = req.body.img;

    Mobiledata = Mobiledata.map(Mobile => {
        if (Mobile.id === idToEdit) {
            return { id: Mobile.id, name: updatedName, price: updatedprice, img: updatedimage };
        }
        return Mobile;
    });

    return res.redirect("/");
});

app.get("/error", (req, res) => {
    res.render("error"); // Render the error.ejs page
});

app.listen(7107, () => {
    console.log("Server started on port 7107");
});
