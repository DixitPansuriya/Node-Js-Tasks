const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Movie = require('./models/Movie');
const User = require('./models/User');

const app = express();
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

const mongoDBUri = 'mongodb+srv://renilbhai1983:blogg123@cluster0.xr3z7.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

mongoose.connect(mongoDBUri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('Could not connect to MongoDB:', err));

app.set('view engine', 'ejs');

// Route to render home page with user info if available
app.get('/', (req, res) => {
  const user = req.query.user || null; // Get user from query parameters if available
  res.render('index', { user });
});

// Route to render login page
app.get('/login', (req, res) => {
  res.render('login');
});

// Route to handle login form submission
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username, password });
    if (user) {
      res.redirect('/?user=' + encodeURIComponent(username)); // Redirect with user info
    } else {
      res.status(401).send('Invalid credentials');
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).send('Server error');
  }
});

// Route to render signup page
app.get('/signup', (req, res) => {
  res.render('signup');
});

// Route to handle signup form submission
app.post('/signup', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = new User({ username, password });
    await user.save();
    res.redirect('/login'); // Redirect to login page after successful signup
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).send('Server error');
  }
});

// Route to fetch and display movies
app.get('/movies', async (req, res) => {
  try {
    const movies = await Movie.find();
    const user = req.query.user || null; // Pass user info to the view
    res.render('movies', { movies, user });
  } catch (error) {
    console.error('Error fetching movies:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Route to render add movie page
app.get('/movies/add', (req, res) => {
  res.render('addMovie');
});

// Route to handle adding a new movie
app.post('/movies', async (req, res) => {
  const { title, director, releaseYear, image } = req.body;
  try {
    const newMovie = new Movie({ title, director, releaseYear, image });
    await newMovie.save();
    res.redirect('/movies');
  } catch (error) {
    console.error('Error adding movie:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Route to render edit movie page
app.get('/movies/edit/:id', async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    if (movie) {
      res.render('editMovie', { movie });
    } else {
      res.status(404).send('Movie not found');
    }
  } catch (error) {
    console.error('Error fetching movie for edit:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Route to handle updating a movie
app.post('/movies/edit/:id', async (req, res) => {
  const { title, director, releaseYear, image } = req.body;
  try {
    const updatedMovie = await Movie.findByIdAndUpdate(
      req.params.id,
      { title, director, releaseYear, image },
      { new: true }
    );
    if (updatedMovie) {
      res.redirect('/movies');
    } else {
      res.status(404).send('Movie not found');
    }
  } catch (error) {
    console.error('Error updating movie:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Route to handle deleting a movie
app.post('/movies/delete/:id', async (req, res) => {
  try {
    const result = await Movie.findByIdAndDelete(req.params.id);
    if (result) {
      res.redirect('/movies');
    } else {
      res.status(404).send('Movie not found');
    }
  } catch (error) {
    console.error('Error deleting movie:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.listen(5050, () => {
  console.log('Server is running on port 5050');
});
