
const http = require('http');
const { readFileSync, readFileAsync } = require('./File');

const hostname = '127.0.0.1';
const port = 6700;

const server = http.createServer((req, res) => {
    if (req.url === '/') {
    
        const content = readFileSync('index.html');
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/html');
        res.end(content);
    } else if (req.url === '/async') {
     
        readFileAsync('index.html', (err, data) => {
            if (err) {
                res.statusCode = 500;
                res.setHeader('Content-Type', 'text/plain');
                res.end('Internal Server Error');
            } else {
                res.statusCode = 200;
                res.setHeader('Content-Type', 'text/html');
                res.end(data);
            }
        });
    } else {
        res.statusCode = 404;
        res.setHeader('Content-Type', 'text/plain');
        res.end('Not Found');
    }
});

server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});
