
const fs = require('fs');
const path = require('path');


function readFileSync(filePath) {
    const fullPath = path.join(__dirname, filePath);
    return fs.readFileSync(fullPath, 'utf8');
}


function readFileAsync(filePath, callback) {
    const fullPath = path.join(__dirname, filePath);
    fs.readFile(fullPath, 'utf8', (err, data) => {
        if (err) {
            callback(err, null);
        } else {
            callback(null, data);
        }
    });
}

module.exports = {
    readFileSync,
    readFileAsync
};
